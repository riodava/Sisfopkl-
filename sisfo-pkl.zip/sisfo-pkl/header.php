<header>
    <h1>sistem informasi PKL SMKN9 MEDAN</h1>
    <p>siswa - halaman untuk isi jurnal dan absen serta konsultasi dengan pembimbing</p>
</header>