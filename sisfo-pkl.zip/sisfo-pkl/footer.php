<footer>
    <p>SMKN9 coding - By bambang</p>
</foother>